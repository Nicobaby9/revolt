<footer class="bg-light py-5">
    <div class="container">
        <div class="small text-center text-muted">Copyright &copy; 2019 - Yudho Aerials</div>
    </div>
</footer>



<script src="<?php echo e(asset('Front-End/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('Front-End/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>


<script src="<?php echo e(asset('Front-End/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('Front-End/vendor/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>


<script src="<?php echo e(asset('Front-End/js/creative.min.js')); ?>"></script>
</html><?php /**PATH C:\Laravela\Perpus\resources\views/footer.blade.php ENDPATH**/ ?>